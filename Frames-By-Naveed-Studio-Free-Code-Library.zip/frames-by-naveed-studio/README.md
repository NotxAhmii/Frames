# Frames By Naveed Studio — Free Code Library

A CodeKart-inspired **original** React/Vite project marketplace for Frames By Naveed Studio.

Reference inspiration: CodeKart's public catalog uses filters for Landing Page, Frontend, Full Stack, UI/Components and tech-stack filters, plus project cards and project detail flows. This implementation recreates the *concept and information architecture*, not CodeKart's proprietary code/design. 

## Included
- Responsive dark premium UI
- 18 free project listings
- Categories: SaaS, E-commerce, Dashboard, Landing Page, Portfolio, Booking & Calendars, Frontend, Full Stack, UI / Components
- Search + category filtering
- Project detail modal
- Direct WhatsApp buttons
- WhatsApp number configured as +92 302 6365630
- Vite + React + Lucide icons

## Run
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Deploy to Vercel
Import this folder into Vercel. The framework can be detected as Vite.

## Add real downloadable ZIP/GitHub projects
The catalog data lives in `src/App.jsx` in the `projects` array. For a production download marketplace, add a `downloadUrl` field to each project and replace the "Request Source" action with a direct GitHub release/ZIP URL.

## WhatsApp
Configured number: `923026365630`.
The site generates `https://wa.me/923026365630?...` links automatically.
