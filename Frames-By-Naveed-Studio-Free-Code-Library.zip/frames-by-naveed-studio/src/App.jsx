import React, { useMemo, useState } from "react";
import { Search, Menu, X, MessageCircle, Download, ArrowRight, Code2, Sparkles, Github, ExternalLink, ChevronDown } from "lucide-react";
import "./styles.css";

const WHATSAPP = "923026365630";
const wa = (text) => `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(text)}`;

const projects = [["Birthday Website Template", "Landing Page", "React • Next.js • Tailwind", "Interactive birthday microsite with gallery, music and animations."], ["Nostalgia Music Player", "Frontend", "React • TypeScript • Tailwind", "Retro music player with playlists, visualizer and responsive controls."], ["OmniSaaS Starter", "SaaS", "Next.js • TypeScript • PostgreSQL", "Multi-tenant SaaS starter with auth, teams and dashboard architecture."], ["AuraCart Store", "E-commerce", "React • TypeScript • Tailwind", "Modern storefront with products, filters, cart and checkout UI."], ["NovaMetric Dashboard", "Dashboard", "Next.js • Recharts • Tailwind", "Analytics dashboard with charts, metrics, tables and dark mode."], ["Creator Portfolio", "Portfolio", "React • TypeScript • Tailwind", "Minimal creative portfolio for photographers, designers and creators."], ["Event Booking App", "Booking & Calendars", "React • Node.js • MongoDB", "Calendar booking interface with availability and appointment flows."], ["Admin UI Kit", "UI / Components", "React • TypeScript • Tailwind", "Reusable buttons, forms, modals, cards, tables and navigation."], ["Agency Landing Page", "Landing Page", "React • Framer Motion • Tailwind", "High-converting agency landing page with smooth motion."], ["Restaurant Ordering UI", "Full Stack", "React • Node.js • MongoDB", "Restaurant menu, cart and order-management starter."], ["Wedding Invitation", "Frontend", "React • Tailwind • Vite", "Elegant digital wedding invitation with schedule and RSVP sections."], ["Photo Gallery CMS", "Full Stack", "Next.js • Prisma • PostgreSQL", "Gallery management starter for photographers and studios."], ["Invoice Dashboard", "Dashboard", "React • TypeScript • Tailwind", "Invoice listing, customer cards, status filters and printable invoices."], ["Link-in-Bio Creator", "SaaS", "Next.js • TypeScript • Tailwind", "Custom profile pages with links, social buttons and themes."], ["Travel Planner", "Frontend", "React • TypeScript • Tailwind", "Trip itinerary interface with destinations, days and notes."], ["Fitness Landing Page", "Landing Page", "React • Tailwind", "Responsive fitness brand landing page with pricing and CTA sections."], ["Online Course UI", "UI / Components", "React • TypeScript • Tailwind", "Course catalog, lesson player and progress dashboard UI."], ["Real Estate Listing", "Full Stack", "Next.js • PostgreSQL • Prisma", "Property search, filters, detail pages and inquiry flow."]];

const categories = [
  "All", "SaaS", "E-commerce", "Dashboard", "Landing Page", "Portfolio",
  "Booking & Calendars", "Frontend", "Full Stack", "UI / Components"
];

function App() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [mobile, setMobile] = useState(false);
  const [selected, setSelected] = useState(null);

  const filtered = useMemo(() => projects.filter(p => {
    const q = query.toLowerCase();
    const matchesQ = !q || p[0].toLowerCase().includes(q) || p[1].toLowerCase().includes(q) || p[2].toLowerCase().includes(q);
    const matchesC = category === "All" || p[1] === category;
    return matchesQ && matchesC;
  }), [query, category]);

  return (
    <div className="app">
      <header className="nav">
        <a className="brand" href="#home" onClick={() => setCategory("All")}>
          <span className="brandMark">FN</span>
          <span><b>Frames By</b><strong>Naveed Studio</strong></span>
        </a>
        <button className="mobileBtn" onClick={() => setMobile(!mobile)}>{mobile ? <X/> : <Menu/>}</button>
        <nav className={mobile ? "navLinks open" : "navLinks"}>
          <a href="#projects" onClick={() => setMobile(false)}>Projects</a>
          <a href="#categories" onClick={() => setMobile(false)}>Categories</a>
          <a href="#about" onClick={() => setMobile(false)}>About</a>
          <a className="navWhats" href={wa("Hi Naveed Studio, I want to discuss a website project.")} target="_blank" rel="noreferrer"><MessageCircle size={17}/> WhatsApp</a>
        </nav>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="glow glow1"></div><div className="glow glow2"></div>
          <div className="heroInner">
            <div className="eyebrow"><Sparkles size={15}/> 100% FREE SOURCE CODE LIBRARY</div>
            <h1>Build faster with <span>free, ready-made</span> web projects.</h1>
            <p>Explore original website templates, dashboards, SaaS starters, UI kits and full-stack projects — curated by Frames By Naveed Studio.</p>
            <div className="heroActions">
              <a href="#projects" className="primary">Explore Projects <ArrowRight size={18}/></a>
              <a href={wa("Hi Naveed Studio, I need a custom website.")} className="secondary" target="_blank" rel="noreferrer"><MessageCircle size={18}/> Get a Custom Website</a>
            </div>
            <div className="stats">
              <div><b>{projects.length}+</b><span>Free Projects</span></div>
              <div><b>10</b><span>Categories</span></div>
              <div><b>100%</b><span>Free Access</span></div>
            </div>
          </div>
        </section>

        <section className="catalog" id="projects">
          <div className="sectionHead">
            <div><div className="eyebrow">CURATED CATALOG</div><h2>Free Production Projects</h2><p>Browse, preview and download projects without a paywall.</p></div>
            <div className="search"><Search size={19}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search projects..." /></div>
          </div>

          <div className="categoryRow" id="categories">
            {categories.map(c => <button key={c} className={category===c ? "active" : ""} onClick={()=>setCategory(c)}>{c}</button>)}
          </div>

          <div className="grid">
            {filtered.map((p,i) => <ProjectCard key={p[0]} project={p} index={i} onOpen={()=>setSelected(p)} />)}
          </div>
          {!filtered.length && <div className="empty"><Code2 size={35}/><h3>No project found</h3><p>Try another search or category.</p></div>}
        </section>

        <section className="feature" id="about">
          <div className="featureIcon"><Code2 size={27}/></div>
          <div><div className="eyebrow">WHY FRAMES BY NAVEED STUDIO</div><h2>Useful code, without the paywall.</h2><p>Our catalog is designed as a free resource for students, creators, freelancers and developers. Every project card clearly shows its stack and intended use.</p></div>
          <a href={wa("Hi Naveed Studio, I want a custom website or project.")} target="_blank" rel="noreferrer" className="primary">Talk on WhatsApp <ArrowRight size={18}/></a>
        </section>
      </main>

      <footer>
        <div className="footerBrand"><span className="brandMark">FN</span><div><b>Frames By Naveed Studio</b><small>Web • Design • Photography</small></div></div>
        <p>© {new Date().getFullYear()} Frames By Naveed Studio. Free project library.</p>
        <a href={wa("Hi Naveed Studio!") } target="_blank" rel="noreferrer"><MessageCircle size={18}/> WhatsApp</a>
      </footer>

      <a className="floatWa" href={wa("Hi Naveed Studio, I found your project library.")} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"><MessageCircle size={25}/></a>

      {selected && <Modal project={selected} close={()=>setSelected(null)} />}
    </div>
  );
}

function ProjectCard({project, index, onOpen}) {
  const [title, category, stack, desc] = project;
  return <article className="card">
    <div className="thumb"><span>{category}</span><div className="codeArt"><Code2 size={35}/><i></i><i></i><i></i></div><small>FREE SOURCE CODE</small></div>
    <div className="cardBody">
      <div className="version">v1.0.0 <span>•</span> Original Template</div>
      <h3>{title}</h3><p>{desc}</p>
      <div className="tags">{stack.split(" • ").map(x=><em key={x}>{x}</em>)}</div>
      <div className="cardFoot"><b>FREE</b><button onClick={onOpen}>Explore <ArrowRight size={16}/></button></div>
    </div>
  </article>
}

function Modal({project, close}) {
  const [title, category, stack, desc] = project;
  const msg = `Hi Naveed Studio, I want the "${title}" project source code.`;
  return <div className="modalBg" onClick={close}><div className="modal" onClick={e=>e.stopPropagation()}>
    <button className="close" onClick={close}><X/></button>
    <div className="modalBadge">FREE SOURCE CODE</div>
    <h2>{title}</h2><p>{desc}</p>
    <div className="modalInfo"><div><small>Category</small><b>{category}</b></div><div><small>Technology</small><b>{stack}</b></div><div><small>License</small><b>Free to access</b></div></div>
    <div className="notice">This catalog is built to distribute original/free projects. Add your actual ZIP or GitHub URL in <code>src/App.jsx</code> when you publish each downloadable project.</div>
    <div className="modalActions"><a className="primary" href={wa(msg)} target="_blank" rel="noreferrer"><MessageCircle size={18}/> Request Source</a><button className="secondary" onClick={close}>Close</button></div>
  </div></div>
}

export default App;
